<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Go-Green-RegistrationForm!</title>

    <!-- Icons font CSS-->
    <link href="assets/reg/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="assets/reg/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="assets/reg/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/reg/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="assets/reg/css/main.css" rel="stylesheet" media="all">
    <script type="text/javascript"> 
       function checkPassword(form) {
                password = form.password.value;
                password2 = form.password2.value;
                // If Not same return False.    
                if (password != password2) {
                    alert ("\nPassword did not match: Please try again...")
                    return false;
                }
                // If same return True.
                else{
                    alert("Password Match!")
                    return true;
                }
            }
</script>
</head>

<body>
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <div class="p-t-2">
                            <button class="btn--red" onclick="document.location='index.php'"><i class="fa fa-arrow-left" aria-hidden="true"></i>Home</button>
                        </div>
                    <h2 class="title">Go Green</h2>
                    <form  onSubmit="return checkPassword(this)" method="POST" action="codes/registerac.php">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Name</label>
                                    <input class="input--style-4" type="text" name="name" required oninvalid="this.setCustomValidity('Enter User Name Here')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email</label>
                                    <input class="input--style-4" type="email" name="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Enter the email here')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div>
                        </div>
                         <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Mobile</label>
                                    <input class="input--style-4" type="text" name="mobile" required pattern="[789][0-9]{9}" oninvalid="this.setCustomValidity('Enter the Mobile number')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Address</label>
                                    <input class="input--style-4" type="text" name="address" required oninvalid="this.setCustomValidity('Enter the Address')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div>
                        <!-- div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Username</label>
                                    <input class="input--style-4" type="text" name="username" required oninvalid="this.setCustomValidity('Enter the Username')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div> -->
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Password</label>
                                    <input class="input--style-4" type="password" required name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" oninvalid="this.setCustomValidity('Enter the Password')"
                                           oninput="this.setCustomValidity('')"/>
                                </div>
                            </div>
                        </div>
                       <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Confirm Password</label>
                                    <input class="input--style-4" type="password" required name="password2">
                                </div>
                            </div>
                        </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Submit</button>
                        </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="reset">Reset</button>
                        </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" onclick="document.location='login.php' ">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="assets/reg/vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="assets/reg/vendor/select2/select2.min.js"></script>
    <script src="assets/reg/vendor/datepicker/moment.min.js"></script>
    <script src="assets/reg/vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="assets/reg/js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->