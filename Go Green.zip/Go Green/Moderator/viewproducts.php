<?php
include_once 'config.php';
$result = mysqli_query($conn,"SELECT * FROM `tbl_products`");
$row = mysqli_fetch_assoc($result);
?>
<table class="table table-bordered table-striped table-hover">
	<h1>Users</h1><hr>
	<tr>
		<th>Name</th>
		<th>Description</th>
		<th>Quantity</th>
		<th>Price</th>
		<!-- <th>Room Type</th>
		<th>Check in Date</th>
		<th>Check Out Time</th>
		<th>Check Out Date</th>
		<th>Occupancy</th>
		<th>Cancel Order</th> -->
	</tr>
              <tr>
              <?php
                while($row = $result->fetch_assoc()){
                $id=$row["id"];
                  echo '<tr class="">';
                  echo '<td class="">';echo $row["pname"];echo'</td>';
                  echo '<td class="">';echo $row["des"];echo '</td>';
                  echo '<td class="">';echo $row["quantity"];echo '</td>';
                  echo '<td class="">';echo $row["price"];echo '</td>';
                  ?>
		<td><a style="color:red" href="delete.php?booking_id=<?php echo $id; ?>">Delete</a></td>
		<?php
                  echo '</tr>';
              }
             ?>   
         </tr>
</table>
