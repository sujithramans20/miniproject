<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password, $dbname);
$email = sha1($_POST['email']);
$email1 = $_POST['email'];
$newpassword = sha1($_POST['password']);
$newpassword1 = $_POST['password'];
$query = "SELECT * FROM `tbl_login` WHERE email='$email' and password='$newpassword'";
$result = mysqli_query($conn, $query);
$value =  $result->fetch_assoc();
if (mysqli_num_rows($result) > 0) {
   if ($value['uid'] == 1) {
      $_SESSION['eval'] = $value['login_id'];
      header('Location:../Evaluator/index.php');
   } else if ($value['uid'] == 2) {
      $_SESSION['admin'] = $value['login_id'];
      header('Location:../Moderator/index.php');
   } else if ($value['uid'] == 3) {
      $_SESSION['user'] = $value['login_id'];
      header('Location:../user/index.php');
   } else {
?> <script>
         alert("invalid user");
      </script><?php
            }
         } else {
               ?>
      <script>
      alert("invalid username or password");
      window.location.href = "../login.php";
     </script>
   <?php
         }






         // else{
         //       $query = "SELECT * FROM `evaluator` WHERE email='$email1'and password='$password1'";
         //       $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
         //       $rows = mysqli_num_rows($result);
         //       echo $rows;
         //       if($rows ==1){
         //             $value =  $result->fetch_assoc() ;
         //             $_SESSION['eid']=$value['eid'];
         //             if(isset($_SESSION["eid"])){
         //                header("Location:../Evaluator/index.html");
         //             } 
         //       }
         // else{
         //             $_SESSION["login_id"]="NULL";
         //             if($_SESSION["login_id"]=="NULL")
         //             {
         //                echo "<script>
         //                alert('Username and Password did not match');
         //                alert('Try Again');
         //                window.location.href='../index.html';
         //                </script>";
         //             }

         //          }
         // }

         mysqli_close($conn);
