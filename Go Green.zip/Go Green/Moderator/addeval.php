<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password, $dbname);
$name = $email = $phone = $state = $district = $city = $password = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$address=$_POST['address'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$city = $_POST['city'];
	$password = $_POST['password'];
	if ($phone){
		$select = mysqli_query($conn,"SELECT * FROM tbl_login WHERE email ='$email'");
		if (mysqli_num_rows($select) > 0) {
			echo ('This email already exists');
		} else {

			$em = sha1($email);
			$pass = sha1($password);

			$qr1 = "INSERT INTO `tbl_login`(email,password,uid) values('$em','$password',1)";
			if (mysqli_query($conn, $qr1)) {
				$sel = mysqli_query($conn, "select * from tbl_login where email='$em'");
				$lid = mysqli_fetch_array($sel);

				$qr = "INSERT INTO `tbl_evaluator`(name,email,phone,address,state,district,city,login_id) values('$name','$email','$phone','$address','$state','$district','$city','$lid[login_id]')";
				if (mysqli_query($conn, $qr)) {
					echo '<script>alert("Succesfully inserted");</script>';
				}
			}
		}
	}
}
?>
<form  method="POST" enctype="multipart/form-data" action="#">
	<table class="table table-bordered">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<tr>
			<th>Name</th>
			<td><input type="text" name="name" class="form-control" name="name"  />
			</td>
		</tr>
		<tr>
			<th>Email</th>
			<td><input type="text" name="email" class="form-control"/>
			</td>
		</tr>

		<tr>
			<th>Phone</th>
			<td><input type="text" name="phone" class="form-control"  />
			</td>
		</tr>

	<!-- 	<tr>
			<th>Password</th>
			<td><input type="text" name="password" value="<?php echo(@$result); ?>" readonly="readonly" class="form-control" /></td>
		</tr>

		<tr>
			<td colspan="2">
				<input type="submit" name="gen">
			</td>
		</tr> -->

		<tr>
			<th>Address</th>
			<td><input type="text" name="address" class="form-control"/>
			</td>
		</tr>
		<tr>
			<th>State</th>
			<td><select class="form-control" id="country-dropdown" name="state">
					<option value="">Select State</option>
					<?php
					require_once "config.php";
					$result = mysqli_query($conn, "SELECT * FROM countries");
					while ($row = mysqli_fetch_array($result)) {
					?>
						<option value="<?php echo $row['id']; ?>"><?php echo $row["name"]; ?></option>
					<?php
					}
					?>
				</select></td>
		</tr>
		<tr>
			<th>District</th>
			<td><select class="form-control" id="state-dropdown" name="district"/>
				</select></td>
		</tr>
		<tr>
			<th>City</th>
			<td>
				<select class="form-control" id="city-dropdown" name="city"/>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" class="btn btn-primary" value="Add" name="add" />
			</td>
		</tr>
		<script>
			$(document).ready(function() {
				$('#country-dropdown').on('change', function() {
					var country_id = this.value;
					$.ajax({
						url: "states-by-country.php",
						type: "POST",
						data: {
							country_id: country_id
						},
						cache: false,
						success: function(result) {
							$("#state-dropdown").html(result);
							$('#city-dropdown').html('<option value="">Select State First</option>');
						}
					});
				});
				$('#state-dropdown').on('change', function() {
					var state_id = this.value;
					$.ajax({
						url: "cities-by-state.php",
						type: "POST",
						data: {
							state_id: state_id
						},
						cache: false,
						success: function(result) {
							$("#city-dropdown").html(result);
						}
					});
				});
			});
		</script>
	</table>
</form>
<?php
if(isset($_POST["gen"])){
	$len=10;
    $result=' ';
    $ValidChar="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    while(0<$len--)
    {
        $result.=$ValidChar[random_int(0,strlen($ValidChar))];
    }
}
?>