<?php
include 'config.php';
if (isset($_SESSION["user"])) {
?>
	<html>

	<body>
		<table class="table table-bordered table-striped table-hover">
			<form method="post" enctype="multipart/form-data">

				<h1>Update Password</h1>
				<hr>


				<tr>
					<th>Enter Your New Password</th>
					<td><input type="password" name="np" class="form-control" required />
					</td>
				</tr>

				<tr>
					<th>Enter Your Confirm Password</th>
					<td><input type="password" name="cp" class="form-control" required />
					</td>
				</tr>

				<tr>
					<td colspan="2" align="center">
						<input type="submit" class="btn btn-primary" value="Update Password" name="update" required />
					</td>
				</tr>

			</form>
		</table>
	</body>

	</html>
	<?php
}
if (isset($_POST['update'])) {
	$id = $_SESSION["user"];
	$np = sha1($_POST['np']);
	$up = "update tbl_login set password='$np' where login_id='$id' ";
	if (mysqli_query($conn, $up)) {
	?>
		<script>
			alert("updated succesfully");
		</script>
<?php
	}
}
?>