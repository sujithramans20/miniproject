<?php include 'config.php';
if (isset($_SESSION['user'])) {
  $id = $_SESSION['user'];
  $sql = mysqli_query($con, "select * from tbl_users where login_id='$id'");

  $r = mysqli_fetch_array($sql); ?>
  <table class="table table-bordered table-striped table-hover">
    <h1>View Booking Status </h1>
    <hr>
    <tr>

      <th>LaundryType</th>
      <th>LaundryDate</th>
      <th>Cancel</th>
    </tr>
    <?php
    $sql = mysqli_query($con, "SELECT * FROM tbl_bookslot b,tbl_users l where b.userid=$r[userid] and l.userid=$r[userid] ");
    while ($res = mysqli_fetch_assoc($sql)) {

    ?>
      <tr>
        <!-- <td><?php echo $i;
              $i++; ?></td> -->

        <td><?php echo $res['laundry_type']; ?></td>
        <td><?php echo $res['booking_date']; ?></td>
        <td><a style="color:red" href="cancel_order.php?id=<?php echo $res['lid']; ?>">Cancel</a></td>
        </td>
      </tr>
    <?php
    }
    ?>
  </table>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="../login.html?e=1"</script>');
  } else {
    header("location:../login.html?e=1");
    die();
  }
}

?>