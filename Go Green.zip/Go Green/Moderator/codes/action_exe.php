<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password,$dbname);
$Name = $phone = $district = $city = "";
if($_SERVER['REQUEST_METHOD'] == "POST"){
$Name =$_POST['Name'];
$phone =$_POST['phone'];
$district =$_POST['district'];
$city =$_POST['city'];

	if($city){
		$details = "INSERT INTO  `tbl_evaluators`(Name,phone,district,city) VALUES ('$Name','$phone','$district','$city')";
		if(mysqli_query($conn,$details)) {
			    header("Location:../add evaluator.html");
		}
		else {
			echo mysqli_error($conn);
			echo"invalid user details";
		}
	}
	else {
		echo mysqli_error($conn);
		echo"user not found";
	}
}
mysqli_close($conn);
?>