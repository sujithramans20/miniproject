<?php include 'config.php';
if (isset($_SESSION['user'])) {
  $id = $_SESSION['user'];
  $sql = mysqli_query($con, "select * from tbl_users where id='$id'");
  $r = mysqli_fetch_array($sql); ?>
  <table class="table table-bordered table-striped table-hover">
    <h1>View Booking Status </h1>
    <hr>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Address</th>
      <th>State</th>
      <th>District</th>
      <th>City</th>
      <th>Evaluator</th>
      <th>Date</th>
      <th>Time</th>
      <th>Cancel</th>

    </tr>
    <?php
    $sql = mysqli_query($conn, "SELECT * FROM tbl_slot b,tbl_users l where b.id=$r[id] and l.id=$r[id] ");
    while ($res = mysqli_fetch_assoc($sql)) {

    ?>
      <tr>
        <!-- <td><?php echo $i;
              $i++; ?></td> -->
        <td><?php echo $res['name']; ?></td>
        <td><?php echo $res['email']; ?></td>
        <td><?php echo $res['phone']; ?></td>
        <td><?php echo $res['address']; ?></td>
        <td><?php echo $res['state']; ?></td>
        <td><?php echo $res['district']; ?></td>
        <td><?php echo $res['city']; ?></td>
        <td><?php echo $res['evaluator']; ?></td>
        <td><?php echo $res['date']; ?></td>
        <td><?php echo $res['time']; ?></td>
        <td><a style="color:red" href="cancel_order.php?id=<?php echo $res['lid']; ?>">Cancel</a></td>
        </td>
      </tr>
    <?php
    }
    ?>
  </table>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="../login.php?e=1"</script>');
  } else {
    header("location:../login.php?e=1");
    die();
  }
}

?>