<?php
include_once 'config.php';
$user =$_SESSION['user'];
$result = mysqli_query($conn,"SELECT * FROM `tbl_users`");
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://fonts.googleapis.com/css?family=Baloo+Bhai" rel="stylesheet">
</head>
<body>
<br>
<div class="container"style="width:100%;">
  <form action="/action_page.php">
    <div class="form-group">
      <label for="email">Name:</label>
       <input type="text" id="name" value="<?php echo $row['name']; ?>" class="form-control" name="name" readonly="readonly"/>
    </div>
    <div class="form-group">
      <label for="">Email</label>
      <input type="text" class="form-control" id="pwd"  name="pwd"value="<?php echo $row['email']; ?>" readonly="readonly">
    </div>
    <div class="form-group">
      <label for="">Mobile</label>
      <input type="text" class="form-control" id="pwd"  name="pwd"value="<?php echo $row['mobile']; ?>" readonly="readonly">
    </div>
    <div class="form-group">
      <label for="">Address</label>
      <input type="text" class="form-control" id="pwd" name="pwd"value="<?php echo $row['address']; ?>" readonly="readonly">
    </div>
  </form>
</div>
</body>
</html>