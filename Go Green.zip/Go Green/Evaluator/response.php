<form method="POST" enctype="multipart/form-data" action="#">
	<table class="table table-bordered">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<tr>
			<th>Name</th>
			<td><input type="text" name="name" class="form-control" name="name" required oninvalid="this.setCustomValidity('Enter User Name Here')" oninput="this.setCustomValidity('')" />
			</td>
		</tr>

		<tr>
			<th>Email</th>
			<td><input type="text" name="email" class="form-control" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Enter the email here')" oninput="this.setCustomValidity('')" />
			</td>
		</tr>

		<tr>
			<th>Phone</th>
			<td><input type="text" name="phone" class="form-control" required pattern="[789][0-9]{9}" oninvalid="this.setCustomValidity('Enter the Mobile number')" oninput="this.setCustomValidity('')" />
			</td>
		</tr>