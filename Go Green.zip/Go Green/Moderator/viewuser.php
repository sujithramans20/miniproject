<?php
include_once 'config.php';
$result = mysqli_query($conn,"SELECT * FROM `tbl_users`");
$row = mysqli_fetch_assoc($result);
?>
<table class="table table-bordered table-striped table-hover">
	<h1>Users</h1><hr>
	<tr>
		<th>Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th>Address</th>
		<!-- <th>Room Type</th>
		<th>Check in Date</th>
		<th>Check Out Time</th>
		<th>Check Out Date</th>
		<th>Occupancy</th>
		<th>Cancel Order</th> -->
	</tr>
              <tr>
              <?php
                while($row = $result->fetch_assoc()){
                $id=$row["id"];
                  echo '<tr class="">';
                  echo '<td class="">';echo $row["name"];echo'</td>';
                  echo '<td class="">';echo $row["email"];echo '</td>';
                  echo '<td class="">';echo $row["mobile"];echo '</td>';
                  echo '<td class="">';echo $row["address"];echo '</td>';
                  echo '</tr>';
              }
             ?>   
         </tr>
</table>