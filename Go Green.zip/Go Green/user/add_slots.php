<?php
//session_start();
// error_reporting(1);
include('config.php');
if (isset($_SESSION['user'])) {
  $id = $_SESSION['user'];
  if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $state=$_POST['state'];
    $district=$_POST['district'];
    $city=$_POST['city'];
    $evaluator=$_POST['evaluator'];
    $date=$_POST['date'];
    $time=$_POST['time'];
    $sql = mysqli_query($conn,"select * from tbl_users where id='$id'");
    $r = mysqli_fetch_array($sql);
    if (mysqli_query($conn, "insert into tbl_slot(name,email,phone,address,state,district,city,evaluator,date,time,id)values('$name','$email','$phone','$address','$state','$district','$city','$evaluator','$date','$time','$r[id]')")) {
?>
      <script>
        alert("Slot Booked");
      </script>

  <?php
      header('location:index.php?option=add');
    }
  }
  ?>
<form method="POST" enctype="multipart/form-data" action="#">
<table class="table table-bordered">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<tr>	
		<th>Name</th>
		<td><input type="text" name="name"  class="form-control"required oninvalid="this.setCustomValidity('Enter User Name Here')" oninput="this.setCustomValidity('')"/>
		</td>
	</tr>
	
	<tr>	
		<th>Email</th>
		<td><input type="text" name="email"  class="form-control"required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Enter the email here')" oninput="this.setCustomValidity('')"/>
		</td>
	</tr>
	
	<tr>	
		<th>Phone</th>
		<td><input type="text" name="phone"  class="form-control" required pattern="[789][0-9]{9}" oninvalid="this.setCustomValidity('Enter the Mobile number')" oninput="this.setCustomValidity('')"/>
		</td>
	</tr>
	<tr>	
		<th>Address</th>
		<td><textarea name="address" class="form-control" required oninvalid="this.setCustomValidity('Enter the Address')" oninput="this.setCustomValidity('')"></textarea>
		</td>
	</tr>
	<tr>
		<th>State</th>
		<td>
	 <select class="form-control" id="country-dropdown" name="state" required oninvalid="this.setCustomValidity('Enter the State')" oninput="this.setCustomValidity('')">
					<option value="">Select State</option>
					<?php
					require_once "config.php";
					$result = mysqli_query($conn, "SELECT * FROM countries");
					while ($row = mysqli_fetch_array($result)) {
					?>
						<option value="<?php echo $row['id']; ?>"><?php echo $row["name"]; ?></option>
					<?php
					}
					?>
				</select></td>
		</tr>
	<tr>	
	<tr>
			<th>District</th>
			<td><select class="form-control" id="state-dropdown" name="district" required oninvalid="this.setCustomValidity('Enter the District')" oninput="this.setCustomValidity('')">
				</select></td>
		</tr>
	  <tr>
			<th>City</th>
			<td>
				<select class="form-control" id="city-dropdown" name="city" required oninvalid="this.setCustomValidity('Enter the City')" oninput="this.setCustomValidity('')">
				</select>
			</td>
		</tr>
	<tr>	
		<tr>
			<th>Evaluator</th>
			<td>
				<select class="form-control" id="eval-dropdown" name="evaluator" required oninvalid="this.setCustomValidity('Enter the City')" oninput="this.setCustomValidity('')">
				</select>
			</td>
		</tr>
		<tr>
		<th>Date</th>
		<td><input type="date" name="date"  class="form-control"  required oninvalid="this.setCustomValidity('Enter the State')" oninput="this.setCustomValidity('')"/>
		</td>
	</tr>
		<tr>
		<th>Time</th>
		<td><input type="time" name="time"  class="form-control"  required oninvalid="this.setCustomValidity('Enter the State')" oninput="this.setCustomValidity('')"/>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="submit" class="btn btn-primary" value="Bookslot" name="add"/>
		</td>
	</tr>
	<script>
			$(document).ready(function() {
				$('#country-dropdown').on('change', function() {
					var country_id = this.value;
					$.ajax({
						url: "states-by-country.php",
						type: "POST",
						data: {
							country_id: country_id
						},
						cache: false,
						success: function(result) {
							$("#state-dropdown").html(result);
							$('#city-dropdown').html('<option value="">Select State First</option>');
						}
					});
				});
				$('#state-dropdown').on('change', function() {
					var state_id = this.value;
					$.ajax({
						url: "cities-by-state.php",
						type: "POST",
						data: {
							state_id: state_id
						},
						cache: false,
						success: function(result) {
							$("#city-dropdown").html(result);
						}
					});
				});
				$('#city-dropdown').on('change', function() {
					var city = this.value;
					$.ajax({
						url: "evaluator.php",
						type: "POST",
						data: {
							city: city
						},
						cache: false,
						success: function(result) {
							$("#eval-dropdown").html(result);
						}
					});
				});
			});
		</script>
</table> 
</form>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="../login.php?e=1"</script>');
  } else {
    header("location:../login.php?e=1");
    die();
  }
}
?>
		