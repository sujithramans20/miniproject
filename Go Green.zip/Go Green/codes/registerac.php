<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password,$dbname);
$name  = $email = $mobile = $address = $password = "";
if($_SERVER['REQUEST_METHOD'] == "POST"){
$name =test_input($_POST['name']);
$email =test_input($_POST['email']);
$mobile = test_input($_POST['mobile']);
$address =test_input($_POST['address']);
// $username =test_input($_POST['username']);
$password =test_input($_POST['password']);
}
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$hashemail=sha1($email);
$hashpassword=sha1($password);
$sql = "INSERT INTO `tbl_login`(email,password,uid) VALUES ('$hashemail','$hashpassword',3)";
//echo $sql;
if (mysqli_query($conn, $sql)){
	$query = "SELECT login_id FROM `tbl_login` WHERE email='$hashemail' and password='$hashpassword'";
	$userId = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($userId);
	$id = $data['login_id'];
	$_SESSION['login_id']=$id;
	if($userId){
		$details = "INSERT INTO `tbl_users` (id,name,email,mobile,address) VALUES ('$id','$name','$email','$mobile','$address')";
		if(mysqli_query($conn, $details)) {
			if(isset($_SESSION["login_id"]))
			{
					header("Location:../login.php");
			}
		}
		else {
			echo mysqli_error($conn);
			echo"invalid user details";
		}
	}
	else {
		echo mysqli_error($conn);
		echo"user not found";
	}
}
else 
{
	echo mysqli_error($conn);
	echo"invalid username or password";
}
mysqli_close($conn);
?>