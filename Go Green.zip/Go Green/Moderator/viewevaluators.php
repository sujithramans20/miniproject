<?php
include_once 'config.php';
$result = mysqli_query($conn,"SELECT * FROM `tbl_evaluator`");
$row = mysqli_fetch_assoc($result);
?>
<table class="table table-bordered table-striped table-hover">
  <h1>Evaluators</h1><hr>
  <tr>
    <th>Name</th>
    <th>phone</th>
   <!--  <th>Mobile</th>
    <th>Address</th> -->
    <!-- <th>Room Type</th>
    <th>Check in Date</th>
    <th>Check Out Time</th>
    <th>Check Out Date</th>
    <th>Occupancy</th>
    <th>Cancel Order</th> -->
  </tr>
              <tr>
              <?php
                while($row = $result->fetch_assoc()){
                $id=$row["eid"];
                  echo '<tr class="">';
                  echo '<td class="">';echo $row["name"];echo'</td>';
                  echo '<td class="">';echo $row["phone"];echo '</td>';
                  // echo '<td class="">';echo $row["mobile"];echo '</td>';
                  // echo '<td class="">';echo $row["address"];echo '</td>';
                  echo '</tr>';
              }
             ?>   
         </tr>
</table>