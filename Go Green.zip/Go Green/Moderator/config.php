<?php 
$conn=mysqli_connect("localhost","root","","godb") or die('DATABASE connection failed');
?>