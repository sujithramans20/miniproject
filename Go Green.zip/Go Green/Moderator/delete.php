<?php 
include('config.php');
$id=$_GET['booking_id'];
$q=mysqli_query($conn,"delete from  tbl_products where id='$id' ");
if($q)
{
header('location:index.php?option=view');
}
?>