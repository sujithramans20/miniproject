<?php 
// if(isset($add))
// {
// 	$sql=mysqli_query($conn,"SELECT * FROM `tbl_products` WHERE pname='$pname'");
// 	if(mysqli_num_rows($sql))
// 	{
// 	echo "this room is already added";	
// 	}		
// 	else
// 	{	
// 	// $img=$_FILES['img']['name'];
// 	mysqli_query($conn,"INSERT INTO `tbl_products`(pname,des,quantity,price) values('$pname','$des','$quantity','$price')");	
// 	// move_uploaded_file($_FILES['img']['tmp_name'],"../image/rooms/".$_FILES['img']['name']);
// 	echo "Rooms added successfully";
// 	}
// }
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password,$dbname);
$pname = $des = $quantity = $price = "";
if($_SERVER['REQUEST_METHOD'] == "POST"){
$pname =$_POST['pname'];
$des =$_POST['des'];
$quantity =$_POST['quantity'];
$price =$_POST['price'];
// $sql=mysqli_query($conn,"SELECT * FROM 'tbl_products' WHERE pname='$pname'");
// 	if(mysqli_num_rows($sql))
//  	{
//  	echo "this room is already added";	
// 	}		
	if($price){
		$select = mysqli_query($conn, "SELECT * FROM tbl_products WHERE pname = '". $_POST['pname']."'");
    if(mysqli_num_rows($select)) {
    echo('This product already exists');
    }
		else 
		{
		   mysqli_query($conn,"INSERT INTO `tbl_products`(pname,des,quantity,price) values('$pname','$des','$quantity','$price')");
		      echo '<script>alert("Succesfully inserted")</script>';
		}
		}
	}
?>
<form method="POST" enctype="multipart/form-data">
<table class="table table-bordered">
	
	<tr>	
		<th>Product Name</th>
		<td><input type="text" name="pname"  class="form-control"/>
		</td>
	</tr>
	
	<tr>	
		<th>Description</th>
		<td><input type="text" name="des"  class="form-control"/>
		</td>
	</tr>
	
	<tr>	
		<th>Quantity</th>
		<td><input type="text" name="quantity"  class="form-control"/>
		</td>
	</tr>

  <tr>	
		<th>Price</th>
		<td><input type="text" name="price"  class="form-control"/>
		</td>
	</tr>

	<tr>
		<td colspan="2">
			<input type="submit" class="btn btn-primary" value="Add" name="add"/>
		</td>
	</tr>
</table> 
</form>
<!-- <script> 
 function change_country() {
   var country = $("#city").val();
   $.ajax({
       type: "POST",
     url: "spec.php",
       data: "country=" + country,
      cache: false,
      success: function(response) {
           //alert(response);return false;
           $("#spec").html(response);
       }
 });
 }
 </script> -->
 <!-- script type="text/javascript">
// 	$(document).ready(function(){
// 		function loadData(type,category_id){
// 			$.ajax({
// 				url : "add_evale.php",
// 				type : "POST",
// 				data :{type : type, id : category_id},
// 				success : function(data){
// 					if(type == "cityData"){
// 						$("#city").html(data)
// 					}
// 					$("#district").append(data);
// 				}
// 			});
// 		}
// 		loadData();
// 		$("#district").on("change",function(){
// 			var district = $("#district").val();
// 			loadData("cityData", district)
// 		})
// 	});
// </script> -->