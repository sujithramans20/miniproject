﻿<?php
session_start();
include '../config.php';
if (isset($_SESSION["eval"])) {
    $id = $_SESSION["eval"];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Evaluator</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <script type="text/javascript"> 
  window.history.forward(); 
  function noBack() { 
      window.history.forward(); 
  } 
</script>
</head>
<body>     
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <h4 style="color:red;"></h4>
                    <a class="navbar-brand" href="#">
                        <img src="" />
                    </a>
                </div>
                 <span class="logout-spn" >
                  <small><a href="logout.php" style="color:#fff;"><i class="fa fa-sign-out" aria-hidden="true"></i></a></small>  
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a href="index.php?option=dash"><i class="fa fa-desktop "></i>Dashboard <span class="badge"></span></a>
                    </li>
                    <li>
                        <a href="index.php?option=vw"><i class="fa-li fa fa-spinner fa-spin"></i>View Slots<span class="badge"></span></a>
                    </li>
                    <li>
                        <a href=""><i class="fa fa-users"></i>View Users<span class="badge"></span></a>
                    </li>
                    <li>
                        <a href="index.php>option=update"><i class="fa fa-cog"></i>Settings</a>
                    </li>
                    <li>
                        <a href="index.php?option=pro"><i class="fa fa-user"></i>Profile</a>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Three </a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-table "></i>My Link Four</a>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Five </a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2></h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <?php
                            @$opt = $_GET['option'];
                            // if($opt=="")
                            // {
                            // include('#'); 
                            // }
                            // else
                            // {
                            if ($opt == "pro") 
                             {
                                include('profile.php');
                             } 
                                else if ($opt == "vw") 
                             {
                                 include('status.php');
                             } 
                                else if ($opt == "update") 
                             {
                                  include('updatepassword.php');
                             } 
                                else if ($opt == "dash") 
                             {
                                include('dash.php');
                             } 
                                //else if ($opt == "view") {
                            //     include('viewproducts.php');
                            // }
                            //   else if($opt=="rooms")
                            //   {
                            //   include('rooms.php');   
                            //   }

                            //   else if($opt=="add_rooms")
                            //   {
                            //   include('add_rooms.php');   
                            //   }
                            //   else if($opt=="delete_room")
                            //   {
                            //   include('delete_room.php'); 
                            //   }

                            // else if($opt=="update_room")
                            // {
                            //   include('update_room.php');
                            // }
                            // else if($opt=="booking_details")
                            // {
                            //   include('booking_details.php');
                            // }
                            // else if($opt=="user_registration")
                            // {
                            //   include('user_registration.php');
                            // }
                            // else if($opt=="admin_profile")
                            // {
                            //   include('admin_profile.php');
                            // }
                            // }
                            ?>
                  <hr />
              
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <div class="footer">
      
    
             <div class="row">
                <div class="col-lg-12" >
                    &copy;  2014 yourdomain.com | Design by: <a href="http://binarytheme.com" style="color:#fff;"  target="_blank">www.binarytheme.com</a>
                </div>
        </div>
        </div>
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
<?php
} else {
    header('location:/Go Green/login.php');
} ?>
