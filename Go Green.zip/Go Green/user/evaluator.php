<?php
require_once "config.php";
$city = $_POST["city"];
$result = mysqli_query($conn,"SELECT * FROM tbl_evaluator where city = $city");
?>
<option value="">Select district</option>
<?php
while($row = mysqli_fetch_array($result)) {
?>
<option value="<?php echo $row["eid"];?>"><?php echo $row["name"];?></option>
<?php
}
?>