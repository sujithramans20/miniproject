﻿<?php
session_start();
include 'config.php';
if (isset($_SESSION["admin"])) {
    $id = $_SESSION["admin"];
?>
    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title></title>
        <!-- BOOTSTRAP STYLES-->
        <link href="assets/css/bootstrap.css" rel="stylesheet" />
        <!-- FONTAWESOME STYLES-->
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
        <link href="assets/css/custom.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
           <script type="text/javascript"> 
  window.history.forward(); 
  function noBack() { 
      window.history.forward(); 
  } 
</script>
    </head>

    <body>
        <div id="wrapper">
            <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"><a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
            </nav>
            <!-- /. NAV TOP  -->
            <nav class="navbar-default navbar-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="main-menu">
                        <li class="text-center">
                            <img src="" class="user-image img-responsive" />
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-desktop"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="index.php?option=add"><i class="fa fa-certificate"></i>Add Evaluator</a>
                        </li>
                        <li>
                            <a href="index.php?option=add1"><i class="fa fa-cart-plus"></i>Add Products</a>
                        </li>
                        <li>
                            <a href="index.php?option=viewusers"><i class="fa fa-users"></i>View Users</a>
                        </li>
                        <li>
                            <a href="index.php?option=viewevals"><i class="fa fa-check-circle-o"></i>View Evaluators</a>
                        </li>
                        <li>
                            <a href="index.php?option=view"><i class="fa fa-shopping-cart"></i>Products</a>
                        </li>
                        <li>
                            <a href="index.php?option=update"><i class="fa fa-wrench"></i>Update</a>
                        </li>
                        <!--   <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>

                                </ul>
                               
                            </li>
                        </ul>
                      </li>   -->
                        <!-- <li>
                        <a class="active-menu"  href="blank.html"><i class="fa fa-square-o fa-3x"></i>Admin</a>
                    </li> -->
                    </ul>
                </div>
            </nav>
            <!-- /. NAV SIDE  -->
            <div id="page-wrapper">
                <div id="page-inner">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Admin</h2>
                           <!--  <h5><?php echo $id; ?></h5> -->
                        </div>
                        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                            <?php
                            @$opt = $_GET['option'];
                            // if($opt=="")
                            // {
                            // include('#'); 
                            // }
                            // else
                            // {
                            if ($opt == "add") {
                                include('addeval.php');
                            } else if ($opt == "add1") {
                                include('codes/add_prod.php');
                            } else if ($opt == "viewusers") {
                                include('viewuser.php');
                            } else if ($opt == "update") {
                                include('updatepassword.php');
                            } else if ($opt == "view") {
                                include('viewproducts.php');
                            }
                              else if($opt=="viewevals")
                            {
                              include('viewevaluators.php');   
                            }

                            //   else if($opt=="add_rooms")
                            //   {
                            //   include('add_rooms.php');   
                            //   }
                            //   else if($opt=="delete_room")
                            //   {
                            //   include('delete_room.php'); 
                            //   }

                            // else if($opt=="update_room")
                            // {
                            //   include('update_room.php');
                            // }
                            // else if($opt=="booking_details")
                            // {
                            //   include('booking_details.php');
                            // }
                            // else if($opt=="user_registration")
                            // {
                            //   include('user_registration.php');
                            // }
                            // else if($opt=="admin_profile")
                            // {
                            //   include('admin_profile.php');
                            // }
                            // }
                            ?>
                        </div>
                    </div>
                    <!-- /. ROW  -->
                    <hr />
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
        <!-- /. WRAPPER  -->
        <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
        <!-- JQUERY SCRIPTS -->
        <script src="assets/js/jquery-1.10.2.js"></script>
        <!-- BOOTSTRAP SCRIPTS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- METISMENU SCRIPTS -->
        <script src="assets/js/jquery.metisMenu.js"></script>
        <!-- CUSTOM SCRIPTS -->
        <script src="assets/js/custom.js"></script>


    </body>

    </html>
<?php
} else {
    header('location:/Go Green/login.php');
} ?>