<?php
//SESSION_START();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "godb";
$conn = new mysqli($servername, $username, $password,$dbname);
if(!$conn){
    die('Could not Connect My Sql:' .mysql_error());
   }
?>