<?php 
extract($_REQUEST);
include('../config.php');
$user=$_SESSION['login_id'];    
if($user=="")
{
    header('location:index.php');
}
?>
//password generater=============================
<?php
if(isset($_POST['Add']))
{
    $len=10;
    $result=' ';
    $ValidChar="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
    while(0<$len--){
        $result.=$ValidChar[random_int(0,strlen($ValidChar))];
    }
}
?>

//text box================================

value=<?php echo(@$result); ?>
==========================================================
    <tr>
            <th hidden="hidden">Password</th>
            <td><input type="hidden" name="password" hidden="hidden" class="form-control"  value="<?php echo(@$result); ?>"    />
            </td>
        </tr>