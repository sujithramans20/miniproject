﻿<?php
session_start();
extract($_REQUEST);
include('config.php');
if (isset($_SESSION['user'])) {
    $id = $_SESSION['user'];
    //$admin=$_SESSION['admin_logged_in'];  
    // if($admin=="")
    // {
    //   header('location:index.php');
    // }
    $sel = mysqli_query($conn,"select * from tbl_login where login_id=$id");
    $f = mysqli_fetch_array($sel);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>     
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="" />
                    </a>
                </div>
              
                 <span class="logout-spn" >
                  <a href="logout.php" style="color:#fff;"><i class="fa fa-sign-out" aria-hidden="true"></i></a>  

                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                 

                    <li>
                        <a href="index.php?option=dash"><i class="fa fa-desktop"></i>Dashboard<span class="badge"></span></a>
                    </li>
                    <li>
                        <a href="index.php?option=add"><i class="fa fa-ticket"></i>Bookslot<span class="badge"></span></a>
                    </li>
                    <li>
                        <a href="index.php?option=update"><i class="fa fa-cog"></i>Settings<span class="badge"></span></a>
                    </li>
                    <li>
                        <a href="index.php?option=pro"><i class="fa fa-user"></i>Profile</a>
                    </li>
                    <!-- <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i>My Link Two</a>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Three </a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-table "></i>My Link Four</a>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Five </a>
                    </li> -->
                </ul>
                            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>BLANK PAGE </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                 <?php
                            @$opt = $_GET['option'];
                            // if($opt=="")
                            // {
                            // include('#'); 
                            // }
                            // else
                            // {
                            if ($opt == "add")
                             {
                                include('add_slots.php');
                             } 
                             else if ($opt == "pro") 
                             {
                                include('profile.php');
                             } 
                             else if ($opt == "update") 
                             {
                                include('updatepassword.php');
                             } 
                             else if ($opt == "dash") 
                             {
                                 include('dash.php');
                             } 
                             //else if ($opt == "view") {
                            //     include('viewproducts.php');
                            // }
                            //   else if($opt=="rooms")
                            //   {
                            //   include('rooms.php');   
                            //   }

                            //   else if($opt=="add_rooms")
                            //   {
                            //   include('add_rooms.php');   
                            //   }
                            //   else if($opt=="delete_room")
                            //   {
                            //   include('delete_room.php'); 
                            //   }

                            // else if($opt=="update_room")
                            // {
                            //   include('update_room.php');
                            // }
                            // else if($opt=="booking_details")
                            // {
                            //   include('booking_details.php');
                            // }
                            // else if($opt=="user_registration")
                            // {
                            //   include('user_registration.php');
                            // }
                            // else if($opt=="admin_profile")
                            // {
                            //   include('admin_profile.php');
                            // }
                            // }
                            ?>
                  <hr />
              
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
             <div>
                 
             </div>
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <div class="footer">
      
    
             <div class="row">
                <div class="col-lg-12" >
                    &copy;  2014 yourdomain.com | Design by: <a href="http://binarytheme.com" style="color:#fff;"  target="_blank">www.binarytheme.com</a>
                </div>
        </div>
        </div>
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
<?php
} else {
    if (headers_sent()) {
        die('<script type="text/javascript">window.location.href="../login.html?e=1"</script>');
    } else {
        header("location:../login.html?e=1");
        die();
    }
}
?>